const courses = [
  { id:'bio', name:'Biología Celular y Genética', semester:1, prereq:[] },
  { id:'anato', name:'Anatomía Humana', semester:1, prereq:[] },
  { id:'quim', name:'Química y Bioquímica', semester:1, prereq:[] },
  { id:'intro', name:'Introducción a Enfermería', semester:1, prereq:[] },
  { id:'psico', name:'Psicología del Desarrollo', semester:1, prereq:[] },

  { id:'fisio', name:'Fisiología', semester:2, prereq:['anato','bio'] },
  { id:'micro', name:'Microbiología y Parasitología', semester:2, prereq:['bio','quim'] },
  { id:'saludpub1', name:'Salud Pública', semester:2, prereq:['intro'] },
  { id:'proc1', name:'Proceso de Enfermería I', semester:2, prereq:['intro','anato'] },
  { id:'comu', name:'Comunicación en Salud', semester:2, prereq:[] },

  { id:'farma', name:'Farmacología', semester:3, prereq:['fisio','quim'] },
  { id:'fisiopato', name:'Fisiopatología', semester:3, prereq:['fisio'] },
  { id:'proc2', name:'Proceso de Enfermería II', semester:3, prereq:['proc1','micro'] },
  { id:'epide', name:'Epidemiología', semester:3, prereq:['saludpub1'] },
  { id:'etica', name:'Ética y Bioética', semester:3, prereq:[] },

  { id:'adulto1', name:'Enfermería del Adulto I', semester:4, prereq:['proc2','fisiopato','farma'] },
  { id:'adulto2', name:'Enfermería del Adulto II', semester:5, prereq:['adulto1'] },
  { id:'materno', name:'Salud Sexual y Reproductiva', semester:5, prereq:['proc2'] },
  { id:'nio1', name:'Enfermería Niño y Adolescente', semester:5, prereq:['proc2'] },
  { id:'gestion1', name:'Gestión en Enfermería I', semester:5, prereq:['saludpub1'] },

  { id:'mental', name:'Salud Mental y Psiquiatría', semester:6, prereq:['adulto1','psico'] },
  { id:'comunitaria', name:'Enfermería Comunitaria', semester:6, prereq:['epide','gestion1'] },
  { id:'nio2', name:'Enfermería Niño y Adolescente II', semester:6, prereq:['nio1'] },
  { id:'materno2', name:'Neonatología y Obstetricia', semester:6, prereq:['materno'] },
  { id:'inv1', name:'Investigación en Salud I', semester:6, prereq:['epide'] },

  { id:'urgencia', name:'Urgencia y Cuidados Críticos', semester:7, prereq:['adulto2'] },
  { id:'gestion2', name:'Gestión en Enfermería II', semester:7, prereq:['gestion1'] },
  { id:'familia', name:'Salud Familiar', semester:7, prereq:['comunitaria'] },
  { id:'inv2', name:'Investigación en Salud II', semester:7, prereq:['inv1'] },
  { id:'electivo1', name:'Electivo de Formación', semester:7, prereq:[] },

  { id:'integrado1', name:'Internado Integrado I', semester:8, prereq:['urgencia','nio2','materno2','mental'] },
  { id:'geronto', name:'Gerontología y Geriatría', semester:8, prereq:['adulto2'] },
  { id:'calidad', name:'Calidad y Seguridad del Paciente', semester:8, prereq:['gestion2'] },
  { id:'electivo2', name:'Electivo Profesional', semester:8, prereq:['electivo1'] },

  { id:'internado2', name:'Internado Profesional II', semester:9, prereq:['integrado1','familia','calidad'] },
  { id:'seminario', name:'Seminario de Título', semester:9, prereq:['inv2'] },

  { id:'internado3', name:'Internado Profesional Final', semester:10, prereq:['internado2','seminario'] },
  { id:'titulo', name:'Actividad de Titulación', semester:10, prereq:['internado2','seminario'] },
];

const unlockedBy = {};
courses.forEach(course => {
  course.prereq.forEach(req => {
    if (!unlockedBy[req]) unlockedBy[req] = [];
    unlockedBy[req].push(course.id);
  });
});

const storageKey = 'malla_ucen_enfermeria_2023';
let passed = JSON.parse(localStorage.getItem(storageKey) || '[]');
let selectedId = null;

function isPassed(id){ return passed.includes(id); }
function isAvailable(course){ return course.prereq.every(id => isPassed(id)); }
function getState(course){
  if (isPassed(course.id)) return 'passed';
  return isAvailable(course) ? 'available' : 'blocked';
}

function save(){ localStorage.setItem(storageKey, JSON.stringify(passed)); }

function renderGrid(){
  const grid = document.getElementById('grid');
  grid.innerHTML = '';
  for (let sem = 1; sem <= 10; sem++) {
    const wrap = document.createElement('section');
    wrap.className = 'semester';
    wrap.innerHTML = `<h3>${sem}° semestre</h3>`;

    courses.filter(c => c.semester === sem).forEach(course => {
      const btn = document.createElement('button');
      const state = getState(course);
      btn.className = `course ${state}`;
      btn.innerHTML = `${course.name}<small>${state === 'passed' ? 'Aprobado' : state === 'available' ? 'Disponible' : 'Bloqueado'}</small>`;
      btn.onclick = () => { selectedId = course.id; renderPanel(); };
      wrap.appendChild(btn);
    });

    grid.appendChild(wrap);
  }
}

function namesFromIds(ids){
  if (!ids || !ids.length) return '<span class="muted">Ninguno</span>';
  return ids.map(id => {
    const c = courses.find(x => x.id === id);
    return `<span class="tag">${c?.name || id}</span>`;
  }).join('');
}

function renderPanel(){
  const panel = document.getElementById('panel');
  const course = courses.find(c => c.id === selectedId);
  if (!course){
    panel.className = 'panel empty';
    panel.innerHTML = '<h2>Selecciona un ramo</h2><p>Aquí verás sus detalles.</p>';
    return;
  }
  const state = getState(course);
  const canPass = state === 'available';
  const dependents = unlockedBy[course.id] || [];

  panel.className = 'panel';
  panel.innerHTML = `
    <h2>${course.name}</h2>
    <p><strong>Semestre:</strong> ${course.semester}°</p>
    <p><strong>Estado:</strong> ${state === 'passed' ? 'Aprobado' : state === 'available' ? 'Disponible' : 'Bloqueado'}</p>
    <p><strong>Prerrequisitos:</strong></p>
    <div>${namesFromIds(course.prereq)}</div>
    <p><strong>Este ramo abre:</strong></p>
    <div>${namesFromIds(dependents)}</div>
    <div class="controls">
      ${!isPassed(course.id) ? `<button class="pass" ${canPass ? '' : 'disabled'} id="passBtn">Marcar aprobado</button>` : `<button class="unpass" id="unpassBtn">Quitar aprobado</button>`}
    </div>
  `;

  const passBtn = document.getElementById('passBtn');
  const unpassBtn = document.getElementById('unpassBtn');
  if (passBtn) {
    passBtn.onclick = () => {
      if (!passed.includes(course.id) && canPass) {
        passed.push(course.id);
        save();
        renderGrid();
        renderPanel();
      }
    };
  }
  if (unpassBtn) {
    unpassBtn.onclick = () => {
      passed = passed.filter(id => id !== course.id);
      save();
      renderGrid();
      renderPanel();
    };
  }
}

document.getElementById('resetBtn').onclick = () => {
  passed = [];
  save();
  renderGrid();
  renderPanel();
};

renderGrid();
renderPanel();
